package Printable;

use Moose::Role;

requires 'as_string';

no Moose::Role;

1;
